//KMeans Clustering

package org.apache.spark.examples.mllib

import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.clustering.KMeans
import scala.io.Source
import org.apache.spark.sql.functions._

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object KMeansClustering {
	
	val conf = new SparkConf().setAppName("KMeansClustering")
	val sc = new SparkContext(conf)
	
	val sqlContext = new org.apache.spark.sql.SQLContext(sc)
	import sqlContext._
	import sqlContext.implicits._
		

	//For batsman -------------------------------------------------------------------------------------------------------------
	//val data1 = sc.textFile("/home/hduser/Desktop/Project/IPL_Project/Clustering/KMeansInput/BattingStats.csv")
	val data1 = sc.textFile("hdfs://localhost:54310/Input/BattingStats.csv")
	val rows1 = data1.map(line => line.split(","))

	//define case class
	case class CC1(Batsman: String, TotMat: Int, Inns: Int, NotOut: Int, Runs: Int, HS: Int, BF: Int, SR: Float, Hundred: Int, Fifty: Int, Fours: Int, Sixes: Int)

	//map parts to case class
	val allData1 = rows1.map( p => CC1(p(0).toString, (p(1).trim).toInt, (p(2).trim).toInt, (p(3).trim).toInt, (p(4).trim).toInt, (p(5).trim).toInt, (p(6).trim).toInt, (p(7).trim).toFloat, (p(8).trim).toInt, (p(9).trim).toInt, (p(10).trim).toInt, (p(11).trim).toInt))
	
		
	//For bowlers --------------------------------------------------------------------------------------------------------------
	//val data2 = sc.textFile("/home/hduser/Desktop/Project/IPL_Project/Clustering/KMeansInput/BowlingStats.csv")
	val data2 = sc.textFile("hdfs://localhost:54310/Input/BowlingStats.csv")
	val rows2 = data2.map(line => line.split(","))

	//define case class
	case class CC2(Bowler: String, TotMat: Int, Inns: Int, Overs: Float, Runs: Int, Wkts: Int, Econ: Float, SR: Float)

	//map parts to case class
	val allData2 = rows2.map( p => CC2(p(0).toString, p(1).trim.toInt, p(2).trim.toInt, (p(3).trim).toFloat, (p(4).trim).toInt, (p(5).trim).toInt, (p(6).trim).toFloat, (p(7).trim).toFloat))

		
	def main(args: Array[String]) {

		//Batsmen ---------------------------------------------------------------------------------------------------------------------------------------------
		//convert rdd to dataframe
		val allDF1 = allData1.toDF()

		//convert back to rdd and cache the data
		val rowsRDD1 = allDF1.rdd.map(r => (r.getString(0), r.getInt(1), r.getInt(2), r.getInt(3), r.getInt(4), r.getInt(5), r.getInt(6), r.getFloat(7), r.getInt(8), r.getInt(9), r.getInt(10), r.getInt(11)))
		rowsRDD1.cache()

		//convert data to RDD which will be passed to KMeans and cache the data. These are the attributes we want to use to assign the instance to a cluster
		val vectors1 = allDF1.rdd.map(r => Vectors.dense(r.getInt(1), r.getInt(2), r.getInt(3), r.getInt(4), r.getInt(5), r.getInt(6), r.getFloat(7), r.getInt(8), r.getInt(9), r.getInt(10), r.getInt(11)))
		vectors1.cache()

		//Based on Silhouette Method
		val numClusters1 = 12
		val numIterations1 = 20
	
		//KMeans model
		val kMeansModel1 = KMeans.train(vectors1, numClusters1, numIterations1)

		//Get the prediction from the model with the ID so we can link them back to other information
		//maps each data row with its cluster index it belongs to. 
		val predictions1 = rowsRDD1.map(r => (r._1, kMeansModel1.predict(Vectors.dense(r._2, r._3, r._4, r._5, r._6, r._7, r._8, r._9, r._10, r._11, r._12))))

		// convert the rdd to a dataframe
		//val predDF1 = predictions1.toDF("Batsman", "CLUSTER")
		//val finalDF1 = allDF1.join(predDF1,"Batsman")

		//Print the center of each cluster
		println(s"\n\nCluster Centers For Batsmen are:")
		kMeansModel1.clusterCenters.foreach(println)
		println(s"\n\n")
		
		// Evaluate clustering by computing Within Set Sum of Squared Errors
    	val WSSSE1 = kMeansModel1.computeCost(vectors1)
    	println(s"\n\nWithin Set Sum of Squared Errors = $WSSSE1\n\n")
    	
    	//Storing The Result
		predictions1.map(x => x._1+","+x._2).saveAsTextFile("/home/hduser/Desktop/Project/IPL_Project/Clustering/KMeansOutput/OutputBatsmen")
		predictions1.map(x => x._1+","+x._2).saveAsTextFile("hdfs://localhost:54310/Output/OutputBatsmen")
		
		


		
		//Bowlers ----------------------------------------------------------------------------------------------------------------------------------------------
		//convert rdd to dataframe
		val allDF2 = allData2.toDF()

		//convert back to rdd and cache the data
		val rowsRDD2 = allDF2.rdd.map(r => (r.getString(0), r.getInt(1), r.getInt(2), r.getFloat(3), r.getInt(4), r.getInt(5), r.getFloat(6), r.getFloat(7)))
		rowsRDD2.cache()

		//convert data to RDD which will be passed to KMeans and cache the data. These are the attributes we want to use to assign the instance to a cluster
		val vectors2 = allDF2.rdd.map(r => Vectors.dense(r.getInt(1), r.getInt(2), r.getFloat(3), r.getInt(4), r.getInt(5), r.getFloat(6), r.getFloat(7)))
		vectors2.cache()

		//Based on Silhouette Method
		val numClusters2 = 15
		val numIterations2 = 20
	
		//KMeans model
		val kMeansModel2 = KMeans.train(vectors2, numClusters2, numIterations2)

		//Get the prediction from the model with the ID so we can link them back to other information
		//maps each data row with its cluster index it belongs to. 
		val predictions2 = rowsRDD2.map(r => (r._1, kMeansModel2.predict(Vectors.dense(r._2, r._3, r._4, r._5, r._6, r._7, r._8))))

		//convert the rdd to a dataframe
		//val predDF2 = predictions2.toDF("Bowler", "CLUSTER")
		//val finalDF2 = allDF2.join(predDF2,"Bowler")

		//Print the center of each cluster
		println(s"\n\nCluster Centers For Bowlers are:")
		kMeansModel2.clusterCenters.foreach(println)
		println(s"\n\n")
		
		// Evaluate clustering by computing Within Set Sum of Squared Errors
    	val WSSSE2 = kMeansModel2.computeCost(vectors2)
    	println(s"\n\nWithin Set Sum of Squared Errors = $WSSSE2\n\n")
		
		//Storing The Result
		predictions2.map(x => x._1+","+x._2).saveAsTextFile("/home/hduser/Desktop/Project/IPL_Project/Clustering/KMeansOutput/OutputBowler")
		predictions2.map(x => x._1+","+x._2).saveAsTextFile("hdfs://localhost:54310/Output/OutputBowler")
		
		
		//Finish.
		sc.stop()
	}
 }
